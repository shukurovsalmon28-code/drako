package uz.drako.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

// One behaviour: which frames to show and how the body moves.
private class Act(
    val frames: IntArray,
    val fps: Float = 6f,
    val speed: Int = 0,
    val hop: Int = 0,
    val hopHz: Float = 1f,
    val shake: Float = 0f,
    val shakeHz: Float = 1f,
    val breathe: Float = 0f,
    val breatheHz: Float = 1f,
    val tilt: Float = 0f,
    val spin: Float = 0f,
    val emoji: String? = null,
    val minMs: Int = 3000,
    val maxMs: Int = 6000
)

class OverlayService : Service() {

    companion object {
        @Volatile
        var running = false
        const val CHANNEL = "drako"
        const val ACTION_STOP = "uz.drako.app.STOP"
    }

    private enum class Mode { GROUND, DRAG, FLY, WALL_L, WALL_R, CEIL }

    // frame groups (indexes into frameIds)
    private val W = intArrayOf(8, 9, 10, 11)
    private val F = intArrayOf(4, 5, 6, 7)
    private val B = intArrayOf(0, 1, 2, 3)
    private val HAPPY = intArrayOf(12)
    private val LEAP = intArrayOf(13)
    private val ROLL = intArrayOf(14)
    private val SLEEP = intArrayOf(15)

    private val frameIds = intArrayOf(
        R.drawable.d_back1, R.drawable.d_back2, R.drawable.d_back3, R.drawable.d_back4,
        R.drawable.d_front1, R.drawable.d_front2, R.drawable.d_front3, R.drawable.d_front4,
        R.drawable.d_walk1, R.drawable.d_walk2, R.drawable.d_walk3, R.drawable.d_walk4,
        R.drawable.d_happy, R.drawable.d_leap, R.drawable.d_roll, R.drawable.d_sleep
    )

    // 38 ground behaviours
    private val acts: List<Act> = listOf(
        Act(W, fps = 7f, speed = 36, minMs = 4000, maxMs = 9000),
        Act(W, fps = 14f, speed = 95, hop = 3, hopHz = 3f, emoji = "💨", minMs = 2500, maxMs = 5000),
        Act(W, fps = 4f, speed = 14, minMs = 3000, maxMs = 6000),
        Act(HAPPY, breathe = 0.02f, breatheHz = 0.7f),
        Act(B, fps = 2f, breathe = 0.015f, breatheHz = 0.7f),
        Act(F, fps = 6f, hop = 2, hopHz = 3f),
        Act(intArrayOf(4, 8, 4, 8), fps = 1.2f, breathe = 0.01f, minMs = 3500, maxMs = 6000),
        Act(LEAP, speed = 30, hop = 26, hopHz = 1.1f),
        Act(LEAP, speed = 55, hop = 34, hopHz = 0.7f, shake = 5f, shakeHz = 1.4f, emoji = "🪽"),
        Act(HAPPY, breathe = 0.09f, breatheHz = 2.5f, minMs = 1500, maxMs = 2500),
        Act(ROLL, speed = 70, spin = 360f, emoji = "🌀", minMs = 2000, maxMs = 3500),
        Act(HAPPY, breathe = 0.12f, breatheHz = 0.6f),
        Act(HAPPY, breathe = 0.06f, breatheHz = 0.5f, emoji = "🥱"),
        Act(SLEEP, breathe = 0.03f, breatheHz = 0.5f, emoji = "😴", minMs = 6000, maxMs = 12000),
        Act(SLEEP, breathe = 0.05f, breatheHz = 0.3f, emoji = "💤", minMs = 8000, maxMs = 14000),
        Act(HAPPY, hop = 8, hopHz = 1.5f, emoji = "☀️", minMs = 2000, maxMs = 3500),
        Act(HAPPY, hop = 8, hopHz = 2f, emoji = "😃"),
        Act(LEAP, hop = 18, hopHz = 2.5f, emoji = "🎉"),
        Act(HAPPY, shake = 5f, shakeHz = 6f, emoji = "😂"),
        Act(HAPPY, breathe = 0.04f, breatheHz = 1.2f, emoji = "❤️"),
        Act(HAPPY, tilt = -12f, emoji = "😢"),
        Act(HAPPY, shake = 2f, shakeHz = 8f, tilt = -6f, emoji = "😭"),
        Act(HAPPY, shake = 4f, shakeHz = 12f, emoji = "😠"),
        Act(HAPPY, hop = 14, hopHz = 1f, emoji = "❗", minMs = 1500, maxMs = 2500),
        Act(B, shake = 6f, shakeHz = 14f, emoji = "😱"),
        Act(intArrayOf(4), tilt = 8f, breathe = 0.02f, emoji = "😊"),
        Act(HAPPY, shake = 8f, shakeHz = 1f, emoji = "❓"),
        Act(ROLL, shake = 15f, shakeHz = 2f, emoji = "😵"),
        Act(intArrayOf(12, 13), fps = 4f, hop = 6, hopHz = 2f, shake = 6f, shakeHz = 2f, emoji = "🎶"),
        Act(HAPPY, breathe = 0.05f, breatheHz = 2f, emoji = "🎵"),
        Act(HAPPY, breathe = 0.06f, breatheHz = 3f, emoji = "🍖"),
        Act(HAPPY, breathe = 0.04f, breatheHz = 2f, emoji = "💧"),
        Act(HAPPY, shake = 2f, shakeHz = 10f, emoji = "🔥"),
        Act(F, fps = 5f, shake = 10f, shakeHz = 3f, emoji = "👋"),
        Act(HAPPY, hop = 10, hopHz = 0.8f, emoji = "🤧"),
        Act(F, fps = 1f, breathe = 0.02f, emoji = "🤔"),
        Act(F, fps = 1f, shake = 4f, shakeHz = 14f, emoji = "🥶"),
        Act(SLEEP, breathe = 0.02f, breatheHz = 0.4f, emoji = "😌")
    )

    private val dragAct = Act(F, fps = 6f, shake = 6f, shakeHz = 8f, emoji = "😮")
    private val panelAct = Act(HAPPY, breathe = 0.03f, breatheHz = 0.8f)
    private val ouchAct = Act(ROLL, shake = 8f, shakeHz = 5f, emoji = "😵", minMs = 1800, maxMs = 1800)

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val rnd = java.util.Random()

    private var fox: ImageView? = null
    private var foxP: WindowManager.LayoutParams? = null
    private var drawables: List<Drawable> = emptyList()
    private var lastFrame = -1

    private var emojiText: FloatText? = null
    private var bubbleText: FloatText? = null
    private var bubbleUntil = 0L
    private var nextPhraseAt = 0L

    private var panel: LinearLayout? = null
    private var replyTv: TextView? = null
    private var inputEt: EditText? = null
    private var busy = false
    private val history = ArrayList<Pair<String, String>>()

    private var mode = Mode.GROUND
    private var curAct: Act = acts[0]
    private var actStart = 0L
    private var actEnd = 0L
    private var dir = 1
    private var px = 0f
    private var py = 0f
    private var vx = 0f
    private var vy = 0f
    private var spinDeg = 0f
    private var flying = false
    private var bounces = 0
    private var edgeDir = 1
    private var edgeEnd = 0L
    private var lastTick = 0L
    private var lastHop = 0f

    private var screenW = 1080
    private var screenH = 1920
    private var navH = 0
    private var statusH = 0

    // touch state
    private var downX = 0f
    private var downY = 0f
    private var downT = 0L
    private var grabX = 0f
    private var grabY = 0f
    private var moved = false
    private var lastX = 0f
    private var lastY = 0f
    private var lastT = 0L
    private var svx = 0f
    private var svy = 0f

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun size(): Int = dp(104)
    private fun maxX(): Float = (screenW - size()).coerceAtLeast(0).toFloat()
    private fun floorY(): Float = (screenH - navH - size()).coerceAtLeast(0).toFloat()
    private fun topY(): Float = statusH.toFloat()
    private fun clampF(v: Float, lo: Float, hi: Float): Float = if (v < lo) lo else if (v > hi) hi else v

    private fun sysDim(name: String): Int {
        val id = resources.getIdentifier(name, "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }

    private fun refreshScreen() {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            screenW = b.width()
            screenH = b.height()
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            screenW = m.widthPixels
            screenH = m.heightPixels
        }
        navH = sysDim("navigation_bar_height")
        statusH = sysDim("status_bar_height")
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startFg()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (fox == null) setup()
        return START_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Drako", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Drako 🐉")
            .setContentText(I18n.t(this, "notif_text"))
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, I18n.t(this, "stop"), stop)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun overlayFlags(touchable: Boolean): Int {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        f = if (touchable) {
            f or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        } else {
            f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        return f
    }

    private fun setup() {
        refreshScreen()
        drawables = frameIds.map { getDrawable(it)!! }

        val s = size()
        val iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.setImageDrawable(drawables[12])
        iv.setOnTouchListener { _, e ->
            onTouch(e)
            true
        }
        val lp = WindowManager.LayoutParams(
            s, s,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            overlayFlags(true),
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        px = screenW / 3f
        py = floorY()
        lp.x = px.toInt()
        lp.y = py.toInt()
        wm.addView(iv, lp)
        fox = iv
        foxP = lp

        emojiText = FloatText(30f, false)
        bubbleText = FloatText(14f, true)

        val now = SystemClock.uptimeMillis()
        lastTick = now
        nextPhraseAt = now + 3000
        pickAct(now)
        handler.post(tick)
    }

    private val tick = object : Runnable {
        override fun run() {
            try {
                step()
            } catch (e: Exception) {
                // ignore single-frame errors
            }
            handler.postDelayed(this, 33)
        }
    }

    // ---------- behaviour picking ----------

    private fun pickAct(now: Long) {
        val idx = if (rnd.nextInt(100) < 35) rnd.nextInt(3) else rnd.nextInt(acts.size)
        startAct(acts[idx], now)
        if (rnd.nextInt(3) == 0) dir = -dir
    }

    private fun startAct(a: Act, now: Long) {
        curAct = a
        actStart = now
        actEnd = now + a.minMs + rnd.nextInt(a.maxMs - a.minMs + 1)
    }

    // ---------- main update ----------

    private fun step() {
        val now = SystemClock.uptimeMillis()
        var dt = (now - lastTick) / 1000f
        lastTick = now
        if (dt > 0.05f) dt = 0.05f
        refreshScreen()
        val maxX = maxX()
        val floor = floorY()
        val top = topY()
        val stick = dp(500).toFloat()

        when (mode) {
            Mode.GROUND -> {
                if (panel == null) {
                    if (now >= actEnd) pickAct(now)
                    val a = curAct
                    if (a.speed > 0) {
                        px += dir * dp(a.speed) * dt
                        if (px <= 0f) {
                            px = 0f
                            dir = 1
                        } else if (px >= maxX) {
                            px = maxX
                            dir = -1
                        }
                    }
                    if (now >= nextPhraseAt) {
                        val list = I18n.phrases(this)
                        say(list[rnd.nextInt(list.size)], 5000L)
                        nextPhraseAt = now + 60000L + rnd.nextInt(60000)
                    }
                }
                px = clampF(px, 0f, maxX)
                py = floor
            }
            Mode.DRAG -> {
                // position is set by touch handler
            }
            Mode.FLY -> {
                vy += dp(1400) * dt
                vx -= vx * 0.2f * dt
                px += vx * dt
                py += vy * dt
                spinDeg += (if (vx >= 0f) 1f else -1f) * 420f * dt
                if (px <= 0f && vx <= 0f) {
                    px = 0f
                    if (Math.abs(vx) > stick) stickTo(Mode.WALL_L, now) else vx = -vx * 0.6f
                } else if (px >= maxX && vx >= 0f) {
                    px = maxX
                    if (Math.abs(vx) > stick) stickTo(Mode.WALL_R, now) else vx = -vx * 0.6f
                }
                if (mode == Mode.FLY && py <= top && vy <= 0f) {
                    py = top
                    if (Math.abs(vy) > dp(350)) stickTo(Mode.CEIL, now) else vy = -vy * 0.5f
                }
                if (mode == Mode.FLY && py >= floor) {
                    py = floor
                    val impact = vy
                    if (impact > dp(700) && bounces < 2) {
                        vy = -impact * 0.3f
                        vx *= 0.7f
                        bounces++
                    } else {
                        land(impact, now)
                    }
                }
            }
            Mode.WALL_L, Mode.WALL_R -> {
                py += edgeDir * dp(36) * dt
                if (py <= top) {
                    py = top
                    edgeDir = 1
                } else if (py >= floor) {
                    py = floor
                    edgeDir = -1
                }
                px = if (mode == Mode.WALL_L) 0f else maxX
                if (now >= edgeEnd) letGo(if (mode == Mode.WALL_L) dp(120).toFloat() else -dp(120).toFloat())
            }
            Mode.CEIL -> {
                px += edgeDir * dp(36) * dt
                if (px <= 0f) {
                    px = 0f
                    edgeDir = 1
                } else if (px >= maxX) {
                    px = maxX
                    edgeDir = -1
                }
                py = top
                if (now >= edgeEnd) letGo(0f)
            }
        }
        render(now)
    }

    private fun stickTo(m: Mode, now: Long) {
        mode = m
        vx = 0f
        vy = 0f
        spinDeg = 0f
        flying = false
        edgeDir = if (rnd.nextBoolean()) 1 else -1
        edgeEnd = now + 6000L + rnd.nextInt(6000)
        hideTexts()
    }

    private fun letGo(sideVx: Float) {
        mode = Mode.FLY
        vx = sideVx
        vy = 0f
        flying = true
        bounces = 0
    }

    private fun land(impact: Float, now: Long) {
        mode = Mode.GROUND
        spinDeg = 0f
        vx = 0f
        vy = 0f
        if (flying && impact > dp(300)) {
            startAct(ouchAct, now)
            val list = I18n.landing(this)
            say(list[rnd.nextInt(list.size)], 3500L)
        } else {
            pickAct(now)
        }
        flying = false
    }

    // ---------- drawing ----------

    private fun render(now: Long) {
        val iv = fox ?: return
        val lp = foxP ?: return
        val s = size()
        var frame = 12
        var rot = 0f
        var sx = 1f
        var sy = 1f
        var hopOff = 0f
        var pivotBottom = true
        var emoji: String? = null

        when (mode) {
            Mode.GROUND, Mode.DRAG -> {
                val a = if (mode == Mode.DRAG) dragAct else if (panel != null) panelAct else curAct
                val t = (now - actStart) / 1000f
                frame = a.frames[(t * a.fps).toInt() % a.frames.size]
                if (a.hop > 0) hopOff = (Math.abs(Math.sin(Math.PI * a.hopHz * t)) * dp(a.hop)).toFloat()
                rot = a.tilt + (a.shake * Math.sin(2.0 * Math.PI * a.shakeHz * t)).toFloat()
                if (a.spin != 0f) {
                    rot += a.spin * t * dir
                    pivotBottom = false
                }
                val br = (a.breathe * Math.sin(2.0 * Math.PI * a.breatheHz * t)).toFloat()
                sy = 1f + br
                sx = 1f - br * 0.5f
                if (dir < 0) sx = -sx
                emoji = if (panel != null && mode == Mode.GROUND) null else a.emoji
            }
            Mode.FLY -> {
                frame = 14
                rot = spinDeg
                pivotBottom = false
            }
            Mode.WALL_L -> {
                frame = W[((now / 140L) % 4L).toInt()]
                rot = 90f
                sx = if (edgeDir > 0) 1f else -1f
                pivotBottom = false
            }
            Mode.WALL_R -> {
                frame = W[((now / 140L) % 4L).toInt()]
                rot = -90f
                sx = if (edgeDir < 0) 1f else -1f
                pivotBottom = false
            }
            Mode.CEIL -> {
                frame = W[((now / 140L) % 4L).toInt()]
                rot = 180f
                sx = if (edgeDir > 0) -1f else 1f
                pivotBottom = false
            }
        }

        if (frame != lastFrame) {
            iv.setImageDrawable(drawables[frame])
            lastFrame = frame
        }
        iv.pivotX = s / 2f
        iv.pivotY = if (pivotBottom) s.toFloat() else s / 2f
        iv.rotation = rot
        iv.scaleX = sx
        iv.scaleY = sy
        lp.x = px.toInt()
        lp.y = (py - hopOff).toInt()
        wm.updateViewLayout(iv, lp)
        lastHop = hopOff

        placeTexts(now, emoji)
    }

    // ---------- floating emoji / speech bubble ----------

    private inner class FloatText(sizeSp: Float, bg: Boolean) {
        val tv = TextView(this@OverlayService)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            overlayFlags(false),
            PixelFormat.TRANSLUCENT
        )
        var shown = false
        var w = 0
        var h = 0

        init {
            tv.textSize = sizeSp
            if (bg) {
                tv.setTextColor(Color.parseColor("#2A2038"))
                tv.maxWidth = dp(240)
                tv.setPadding(dp(12), dp(8), dp(12), dp(8))
                val g = GradientDrawable()
                g.setColor(Color.parseColor("#F6EEFF"))
                g.setStroke(dp(2), Color.parseColor("#9B59D0"))
                g.cornerRadius = dp(14).toFloat()
                tv.background = g
            }
            lp.gravity = Gravity.TOP or Gravity.START
        }

        fun set(text: String) {
            if (tv.text.toString() != text) {
                tv.text = text
                tv.measure(
                    View.MeasureSpec.makeMeasureSpec(screenW, View.MeasureSpec.AT_MOST),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
                )
                w = tv.measuredWidth
                h = tv.measuredHeight
            }
        }

        fun show(x: Int, y: Int) {
            lp.x = x.coerceIn(0, maxOf(0, screenW - w))
            lp.y = y
            if (!shown) {
                wm.addView(tv, lp)
                shown = true
            } else {
                wm.updateViewLayout(tv, lp)
            }
        }

        fun hide() {
            if (shown) {
                try {
                    wm.removeView(tv)
                } catch (e: Exception) {
                }
                shown = false
            }
        }
    }

    private fun placeTexts(now: Long, emoji: String?) {
        val et = emojiText ?: return
        val bt = bubbleText ?: return
        val s = size()
        val cx = px + s / 2f
        val baseY = py - lastHop
        var emojiTop = baseY

        if (emoji != null && (mode == Mode.GROUND || mode == Mode.DRAG)) {
            et.set(emoji)
            val bob = (Math.sin(now / 250.0) * dp(3)).toFloat()
            var ey = baseY - et.h + dp(14) + bob
            if (ey < 0f) ey = 0f
            et.show((cx - et.w / 2f).toInt(), ey.toInt())
            emojiTop = ey
        } else {
            et.hide()
        }

        if (now < bubbleUntil && (mode == Mode.GROUND || mode == Mode.DRAG)) {
            var by = emojiTop - bt.h - dp(4)
            if (by < 0f) by = baseY + s
            bt.show((cx - bt.w / 2f).toInt(), by.toInt())
        } else {
            bt.hide()
        }
    }

    private fun say(text: String, ms: Long) {
        bubbleText?.set(text)
        bubbleUntil = SystemClock.uptimeMillis() + ms
    }

    private fun hideTexts() {
        emojiText?.hide()
        bubbleText?.hide()
        bubbleUntil = 0L
    }

    // ---------- touch: tap, drag and throw ----------

    private fun onTouch(e: MotionEvent) {
        val now = SystemClock.uptimeMillis()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                downT = now
                grabX = e.rawX - px
                grabY = e.rawY - py
                moved = false
                lastX = e.rawX
                lastY = e.rawY
                lastT = now
                svx = 0f
                svy = 0f
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val dy = e.rawY - downY
                val slop = ViewConfiguration.get(this).scaledTouchSlop.toFloat()
                if (!moved && Math.sqrt((dx * dx + dy * dy).toDouble()) > slop) {
                    moved = true
                    startDrag(now)
                }
                if (moved) {
                    px = clampF(e.rawX - grabX, 0f, maxX())
                    py = clampF(e.rawY - grabY, topY(), floorY())
                    val dtt = (now - lastT) / 1000f
                    if (dtt > 0.001f) {
                        svx = svx * 0.5f + ((e.rawX - lastX) / dtt) * 0.5f
                        svy = svy * 0.5f + ((e.rawY - lastY) / dtt) * 0.5f
                    }
                    lastX = e.rawX
                    lastY = e.rawY
                    lastT = now
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!moved) {
                    if (e.actionMasked == MotionEvent.ACTION_UP && now - downT < 500) onTap(now)
                } else {
                    releaseThrow(now)
                }
            }
        }
    }

    private fun startDrag(now: Long) {
        if (panel != null) closePanel()
        mode = Mode.DRAG
        flying = false
        hideTexts()
        actStart = now
    }

    private fun releaseThrow(now: Long) {
        val maxV = dp(2000).toFloat()
        if (now - lastT > 120) {
            vx = 0f
            vy = 0f
        } else {
            vx = clampF(svx, -maxV, maxV)
            vy = clampF(svy, -maxV, maxV)
        }
        mode = Mode.FLY
        flying = true
        bounces = 0
        spinDeg = 0f
    }

    private fun onTap(now: Long) {
        when (mode) {
            Mode.GROUND -> {
                if (panel != null) {
                    closePanel()
                    pickAct(now)
                } else {
                    startAct(Act(HAPPY, hop = 10, hopHz = 2f, emoji = "❤️", minMs = 1200, maxMs = 1200), now)
                    openPanel()
                }
            }
            Mode.WALL_L, Mode.WALL_R, Mode.CEIL -> letGo(0f)
            else -> {
            }
        }
    }

    // ---------- chat panel ----------

    private fun openPanel() {
        bubbleUntil = 0L
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), dp(12), dp(12), dp(12))
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#F6EEFF"))
        bg.setStroke(dp(2), Color.parseColor("#9B59D0"))
        bg.cornerRadius = dp(16).toFloat()
        col.background = bg

        val reply = TextView(this)
        reply.textSize = 15f
        reply.setTextColor(Color.parseColor("#222222"))
        reply.text = I18n.t(this, "chat_hello")
        val scroll = ScrollView(this)
        scroll.addView(reply)
        col.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(150)))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL

        val et = EditText(this)
        et.hint = I18n.t(this, "chat_hint")
        et.setTextColor(Color.parseColor("#222222"))
        et.setHintTextColor(Color.parseColor("#888888"))
        et.maxLines = 3
        et.imeOptions = EditorInfo.IME_ACTION_SEND
        et.setHorizontallyScrolling(false)
        et.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendMessage()
                true
            } else {
                false
            }
        }
        row.addView(et, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val send = Button(this)
        send.text = "➤"
        send.setOnClickListener { sendMessage() }
        row.addView(send, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        val close = Button(this)
        close.text = "✕"
        close.setOnClickListener { closePanel() }
        row.addView(close, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        col.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        val lp = WindowManager.LayoutParams(
            screenW - dp(24),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = dp(48)
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        wm.addView(col, lp)

        panel = col
        replyTv = reply
        inputEt = et
        et.requestFocus()
    }

    private fun closePanel() {
        panel?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        panel = null
        replyTv = null
        inputEt = null
    }

    private fun sendMessage() {
        val et = inputEt ?: return
        val reply = replyTv ?: return
        val q = et.text.toString().trim()
        if (q.isEmpty() || busy) return
        val key = Prefs.key(this)
        if (key.isEmpty()) {
            reply.text = I18n.t(this, "no_key")
            return
        }
        et.setText("")
        history.add(Pair("user", q))
        while (history.size > 12) history.removeAt(0)
        reply.text = I18n.t(this, "thinking")
        busy = true
        val langName = when (I18n.lang(this)) {
            "uz" -> "Uzbek"
            "ru" -> "Russian"
            else -> "English"
        }
        Gemini.ask(key, Prefs.model(this), langName, ArrayList(history)) { result, error ->
            busy = false
            if (result != null) {
                history.add(Pair("model", result))
                replyTv?.text = result
            } else {
                if (history.isNotEmpty()) history.removeAt(history.size - 1)
                replyTv?.text = I18n.t(this, "error") + ": " + (error ?: "")
            }
        }
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        hideTexts()
        closePanel()
        fox?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        fox = null
        super.onDestroy()
    }
}
