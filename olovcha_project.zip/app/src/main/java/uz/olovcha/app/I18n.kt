package uz.olovcha.app

import android.content.Context
import java.util.Locale

object I18n {
    fun lang(c: Context): String {
        val p = Prefs.lang(c)
        if (p != "auto") return p
        return when (Locale.getDefault().language) {
            "uz" -> "uz"
            "ru" -> "ru"
            else -> "en"
        }
    }

    fun t(c: Context, k: String): String {
        val l = lang(c)
        return UI[l]?.get(k) ?: UI["en"]?.get(k) ?: k
    }

    fun phrases(c: Context): List<String> = PH[lang(c)] ?: PH.getValue("en")

    private val PH: Map<String, List<String>> = mapOf(
        "uz" to listOf(
            "Salom! Men Olovchaman 🦊",
            "Suv ichdingmi? 💧",
            "Ko'zlaringga dam ber, biroz uzoqqa qara 👀",
            "Orqangni rostla, to'g'ri o'tir 🙂",
            "Bir piyola choy ichsang-chi? 🍵",
            "Biroz yur, oyoqlaring toshib ketmasin 🚶",
            "Men shu yerdaman, kerak bo'lsam bos! 🦊",
            "Telefonni biroz qo'yib, nafas ol 🌿",
            "Zo'r ishlayapsan, davom et! ✨",
            "Bugun nima yangilik? Menga ayt! 💬"
        ),
        "en" to listOf(
            "Hi! I'm Olovcha 🦊",
            "Did you drink some water? 💧",
            "Rest your eyes, look far away for a bit 👀",
            "Straighten your back and sit up 🙂",
            "How about a cup of tea? 🍵",
            "Take a short walk, stretch your legs 🚶",
            "I'm right here, tap me if you need me! 🦊",
            "Put the phone down and take a breath 🌿",
            "You're doing great, keep going! ✨",
            "What's new today? Tell me! 💬"
        ),
        "ru" to listOf(
            "Привет! Я Оловча 🦊",
            "Ты уже пил воду? 💧",
            "Дай глазам отдохнуть, посмотри вдаль 👀",
            "Выпрями спину и сядь ровно 🙂",
            "Может, выпьешь чашку чая? 🍵",
            "Пройдись немного, разомни ноги 🚶",
            "Я здесь, нажми на меня, если что! 🦊",
            "Отложи телефон и сделай вдох 🌿",
            "Ты молодец, так держать! ✨",
            "Что нового сегодня? Расскажи! 💬"
        )
    )

    private val UI: Map<String, Map<String, String>> = mapOf(
        "uz" to mapOf(
            "app_sub" to "Telefoningizdagi kichkina tulki",
            "start" to "🦊 Olovchani chaqirish",
            "stop" to "Olovchani to'xtatish",
            "status_on" to "Olovcha hozir ekranda yuribdi ✅",
            "status_off" to "Olovcha hozir dam olyapti 💤",
            "perm_title" to "Ruxsatlar",
            "perm_overlay" to "1) Boshqa ilovalar ustida ko'rsatish",
            "perm_battery" to "2) Batareya cheklovisiz ishlash",
            "samsung" to "Samsung: Batareya → Fondagi foydalanish cheklovlari → «Hech qachon uxlamaydigan ilovalar»ga Olovchani qo'shing.",
            "need_overlay" to "Avval «boshqa ilovalar ustida ko'rsatish» ruxsatini bering",
            "lang_title" to "Til",
            "ai_title" to "Suhbat (AI «miya»)",
            "ai_help" to "1) Pastdagi tugma bilan aistudio.google.com/apikey ni oching (Google akkaunt bilan kiring)\n2) «Create API key» ni bosing\n3) Kalitni nusxalab, shu yerga joylang.\nTekin, karta kerak emas. Diqqat: tekin rejimda Google so'rovlarni xizmatni yaxshilash uchun ishlatishi mumkin.",
            "get_key" to "🔑 Tekin kalit olish sahifasi",
            "key_hint" to "Gemini API kaliti",
            "key_saved" to "(saqlangan — almashtirish uchun yangisini yozing)",
            "model_hint" to "Model nomi",
            "save" to "Saqlash",
            "saved" to "Saqlandi ✅",
            "chat_hello" to "Salom! Men Olovchaman 🦊 Nima haqida gaplashamiz?",
            "chat_hint" to "Savolingizni yozing...",
            "send" to "Yuborish",
            "thinking" to "O'ylayapman... 🤔",
            "no_key" to "Avval ilovaga kirib, Gemini kalitini saqlang 🔑",
            "error" to "Xatolik",
            "notif_text" to "Olovcha ekranda yuribdi",
            "about" to "Olovcha — ixtiyoriy loyiha. Savollaringiz faqat siz tanlagan AI xizmatiga (Google Gemini) yuboriladi. Kalitni hech kimga bermang."
        ),
        "en" to mapOf(
            "app_sub" to "A little fox living on your phone",
            "start" to "🦊 Call Olovcha",
            "stop" to "Stop Olovcha",
            "status_on" to "Olovcha is walking on your screen ✅",
            "status_off" to "Olovcha is resting 💤",
            "perm_title" to "Permissions",
            "perm_overlay" to "1) Display over other apps",
            "perm_battery" to "2) Run without battery limits",
            "samsung" to "Samsung: Battery → Background usage limits → add Olovcha to \"Never sleeping apps\".",
            "need_overlay" to "Please allow \"Display over other apps\" first",
            "lang_title" to "Language",
            "ai_title" to "Chat (AI \"brain\")",
            "ai_help" to "1) Open aistudio.google.com/apikey with the button below (sign in with a Google account)\n2) Tap \"Create API key\"\n3) Copy the key and paste it here.\nFree, no card needed. Note: on the free tier Google may use requests to improve its service.",
            "get_key" to "🔑 Open the free key page",
            "key_hint" to "Gemini API key",
            "key_saved" to "(saved — type a new one to replace)",
            "model_hint" to "Model name",
            "save" to "Save",
            "saved" to "Saved ✅",
            "chat_hello" to "Hi! I'm Olovcha 🦊 What shall we talk about?",
            "chat_hint" to "Type your question...",
            "send" to "Send",
            "thinking" to "Thinking... 🤔",
            "no_key" to "Please open the app and save your Gemini key first 🔑",
            "error" to "Error",
            "notif_text" to "Olovcha is on your screen",
            "about" to "Olovcha is a hobby project. Your questions are sent only to the AI service you choose (Google Gemini). Never share your key with anyone."
        ),
        "ru" to mapOf(
            "app_sub" to "Маленькая лисичка на вашем телефоне",
            "start" to "🦊 Позвать Оловчу",
            "stop" to "Остановить Оловчу",
            "status_on" to "Оловча гуляет по экрану ✅",
            "status_off" to "Оловча отдыхает 💤",
            "perm_title" to "Разрешения",
            "perm_overlay" to "1) Показ поверх других приложений",
            "perm_battery" to "2) Работа без ограничений батареи",
            "samsung" to "Samsung: Батарея → Ограничения фонового использования → добавьте Оловчу в «Никогда не спящие приложения».",
            "need_overlay" to "Сначала разрешите «Показ поверх других приложений»",
            "lang_title" to "Язык",
            "ai_title" to "Чат (ИИ-«мозг»)",
            "ai_help" to "1) Откройте aistudio.google.com/apikey кнопкой ниже (войдите в аккаунт Google)\n2) Нажмите «Create API key»\n3) Скопируйте ключ и вставьте сюда.\nБесплатно, карта не нужна. Внимание: в бесплатном режиме Google может использовать запросы для улучшения сервиса.",
            "get_key" to "🔑 Страница бесплатного ключа",
            "key_hint" to "Ключ Gemini API",
            "key_saved" to "(сохранён — введите новый, чтобы заменить)",
            "model_hint" to "Название модели",
            "save" to "Сохранить",
            "saved" to "Сохранено ✅",
            "chat_hello" to "Привет! Я Оловча 🦊 О чём поговорим?",
            "chat_hint" to "Напишите вопрос...",
            "send" to "Отправить",
            "thinking" to "Думаю... 🤔",
            "no_key" to "Сначала откройте приложение и сохраните ключ Gemini 🔑",
            "error" to "Ошибка",
            "notif_text" to "Оловча на вашем экране",
            "about" to "Оловча — любительский проект. Ваши вопросы отправляются только выбранному вами ИИ-сервису (Google Gemini). Никому не передавайте ключ."
        )
    )
}
