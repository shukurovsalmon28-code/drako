package uz.olovcha.app

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Gemini {
    private val main = Handler(Looper.getMainLooper())

    private fun systemText(langName: String): String =
        "You are Olovcha, a cute, friendly little fox who lives on the user's phone screen. " +
            "Answer helpfully but briefly (usually 1-4 short sentences), in plain text without markdown. " +
            "Reply in the same language the user writes in (Uzbek, Russian or English). " +
            "If it is unclear, use $langName."

    fun ask(
        apiKey: String,
        model: String,
        langName: String,
        history: List<Pair<String, String>>,
        onDone: (String?, String?) -> Unit
    ) {
        Thread {
            var result: String? = null
            var error: String? = null
            try {
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 15000
                conn.readTimeout = 40000
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("x-goog-api-key", apiKey)
                conn.doOutput = true

                val contents = JSONArray()
                for ((role, text) in history) {
                    val part = JSONObject().put("text", text)
                    contents.put(
                        JSONObject()
                            .put("role", role)
                            .put("parts", JSONArray().put(part))
                    )
                }
                val sysPart = JSONObject().put("text", systemText(langName))
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(sysPart)))
                    .put("contents", contents)

                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val txt = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""

                if (code in 200..299) {
                    val parts = JSONObject(txt)
                        .getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                    val sb = StringBuilder()
                    for (i in 0 until parts.length()) {
                        sb.append(parts.getJSONObject(i).optString("text"))
                    }
                    val answer = sb.toString().trim()
                    if (answer.isEmpty()) {
                        error = "empty answer"
                    } else {
                        result = answer
                    }
                } else {
                    val msg = try {
                        JSONObject(txt).getJSONObject("error").getString("message")
                    } catch (e: Exception) {
                        txt
                    }
                    error = "HTTP " + code + ": " + msg.take(200)
                }
            } catch (e: Exception) {
                error = e.message ?: e.toString()
            }
            main.post { onDone(result, error) }
        }.start()
    }
}
