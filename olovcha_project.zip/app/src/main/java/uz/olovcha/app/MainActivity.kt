package uz.olovcha.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var statusTv: TextView
    private val brown = Color.parseColor("#3A2A1E")
    private val orange = Color.parseColor("#E8742C")
    private val sand = Color.parseColor("#FFE3C7")

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun t(k: String): String = I18n.t(this, k)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        statusTv.text = if (OverlayService.running) t("status_on") else t("status_off")
    }

    private fun text(s: String, size: Float, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = s
        v.textSize = size
        v.setTextColor(brown)
        if (bold) v.setTypeface(v.typeface, android.graphics.Typeface.BOLD)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(8)
        v.layoutParams = lp
        return v
    }

    private fun button(s: String, primary: Boolean, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = s
        b.isAllCaps = false
        b.setTextColor(if (primary) Color.WHITE else brown)
        val g = GradientDrawable()
        g.cornerRadius = dp(14).toFloat()
        g.setColor(if (primary) orange else sand)
        b.background = g
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(8)
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        return b
    }

    private fun field(hint: String, value: String, secret: Boolean): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(value)
        e.setTextColor(brown)
        e.setHintTextColor(Color.parseColor("#9A8A7A"))
        e.setSingleLine(true)
        if (secret) {
            e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(8)
        e.layoutParams = lp
        return e
    }

    private fun buildUi() {
        val root = ScrollView(this)
        root.setBackgroundColor(Color.parseColor("#FFF8F0"))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(32), dp(20), dp(32))
        root.addView(col)

        // header
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val img = ImageView(this)
        img.setImageResource(R.drawable.fox_face)
        head.addView(img, LinearLayout.LayoutParams(dp(96), dp(72)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.addView(text("Olovcha", 26f, true))
        titles.addView(text(t("app_sub"), 14f))
        head.addView(titles)
        col.addView(head)

        // status + start / stop
        statusTv = text("", 16f, true)
        col.addView(statusTv)
        col.addView(button(t("start"), true) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, t("need_overlay"), Toast.LENGTH_LONG).show()
                openOverlaySettings()
            } else {
                startForegroundService(Intent(this, OverlayService::class.java))
                statusTv.postDelayed({ refreshStatus() }, 600)
            }
        })
        col.addView(button(t("stop"), false) {
            stopService(Intent(this, OverlayService::class.java))
            statusTv.postDelayed({ refreshStatus() }, 600)
        })

        // permissions
        col.addView(text(t("perm_title"), 18f, true))
        col.addView(button(t("perm_overlay"), false) { openOverlaySettings() })
        col.addView(button(t("perm_battery"), false) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        })
        col.addView(text(t("samsung"), 13f))

        // language
        col.addView(text(t("lang_title"), 18f, true))
        val codes = arrayOf("auto", "uz", "en", "ru")
        val names = arrayOf("Auto", "O'zbekcha", "English", "Русский")
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        sp.setSelection(codes.indexOf(Prefs.lang(this)).coerceAtLeast(0))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                if (codes[pos] != Prefs.lang(this@MainActivity)) {
                    Prefs.setLang(this@MainActivity, codes[pos])
                    recreate()
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        col.addView(sp)

        // AI
        col.addView(text(t("ai_title"), 18f, true))
        col.addView(text(t("ai_help"), 13f))
        col.addView(button(t("get_key"), false) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")))
        })
        val hasKey = Prefs.key(this).isNotEmpty()
        val keyEt = field(if (hasKey) t("key_saved") else t("key_hint"), "", true)
        col.addView(keyEt)
        val modelEt = field(t("model_hint"), Prefs.model(this), false)
        col.addView(modelEt)
        col.addView(button(t("save"), true) {
            val k = keyEt.text.toString().trim()
            if (k.isNotEmpty()) {
                Prefs.setKey(this, k)
                keyEt.setText("")
                keyEt.hint = t("key_saved")
            }
            val m = modelEt.text.toString().trim()
            Prefs.setModel(this, if (m.isEmpty()) Prefs.DEFAULT_MODEL else m)
            Toast.makeText(this, t("saved"), Toast.LENGTH_SHORT).show()
        })

        col.addView(text(t("about"), 12f))
        setContentView(root)
    }

    private fun openOverlaySettings() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName))
        )
    }
}
