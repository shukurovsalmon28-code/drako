package uz.olovcha.app

import android.content.Context

object Prefs {
    const val DEFAULT_MODEL = "gemini-flash-latest"

    private fun sp(c: Context) = c.getSharedPreferences("olovcha", Context.MODE_PRIVATE)

    fun key(c: Context): String = sp(c).getString("key", "") ?: ""
    fun setKey(c: Context, v: String) = sp(c).edit().putString("key", v).apply()

    fun model(c: Context): String = sp(c).getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
    fun setModel(c: Context, v: String) = sp(c).edit().putString("model", v).apply()

    fun lang(c: Context): String = sp(c).getString("lang", "auto") ?: "auto"
    fun setLang(c: Context, v: String) = sp(c).edit().putString("lang", v).apply()
}
