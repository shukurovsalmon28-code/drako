package uz.olovcha.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class OverlayService : Service() {

    companion object {
        @Volatile
        var running = false
        const val CHANNEL = "olovcha"
        const val ACTION_STOP = "uz.olovcha.app.STOP"
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val rnd = java.util.Random()

    private var fox: ImageView? = null
    private var foxP: WindowManager.LayoutParams? = null
    private var walkFrames: List<Drawable> = emptyList()
    private var face: Drawable? = null

    private var bubbleV: TextView? = null
    private var bubbleP: WindowManager.LayoutParams? = null
    private var bubbleShown = false

    private var panel: LinearLayout? = null
    private var replyTv: TextView? = null
    private var inputEt: EditText? = null
    private var busy = false
    private val history = ArrayList<Pair<String, String>>()

    private var frameIdx = 0
    private var dir = 1
    private var x = 0
    private var walking = true
    private var stateTicks = 30

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun foxH(): Int = dp(84)
    private fun foxW(): Int = foxH() * 221 / 166
    private fun foxBottom(): Int = dp(24)
    private fun screenW(): Int = resources.displayMetrics.widthPixels

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startFg()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (fox == null) setup()
        return START_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Olovcha", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Olovcha 🦊")
            .setContentText(I18n.t(this, "notif_text"))
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, I18n.t(this, "stop"), stop)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun setup() {
        walkFrames = listOf(
            R.drawable.fox_walk1, R.drawable.fox_walk2, R.drawable.fox_walk3, R.drawable.fox_walk4
        ).map { getDrawable(it)!! }
        face = getDrawable(R.drawable.fox_face)

        val iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.setImageDrawable(face)
        iv.setOnClickListener { togglePanel() }

        val lp = WindowManager.LayoutParams(
            foxW(), foxH(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.BOTTOM or Gravity.START
        x = screenW() / 3
        lp.x = x
        lp.y = foxBottom()
        wm.addView(iv, lp)
        fox = iv
        foxP = lp

        handler.post(tick)
        handler.postDelayed(phraseRun, 3000)
    }

    private val tick = object : Runnable {
        override fun run() {
            try {
                step()
            } catch (e: Exception) {
                // ignore single-frame errors
            }
            handler.postDelayed(this, 140)
        }
    }

    private fun step() {
        val f = fox ?: return
        val p = foxP ?: return
        if (panel != null) {
            f.setImageDrawable(face)
            f.scaleX = 1f
            return
        }
        stateTicks--
        if (stateTicks <= 0) {
            walking = !walking
            stateTicks = if (walking) 30 + rnd.nextInt(60) else 15 + rnd.nextInt(30)
            if (walking && rnd.nextBoolean()) dir = -dir
        }
        if (walking) {
            x += dir * dp(5)
            val maxX = screenW() - foxW()
            if (x <= 0) {
                x = 0
                dir = 1
            } else if (x >= maxX) {
                x = maxX
                dir = -1
            }
            frameIdx = (frameIdx + 1) % walkFrames.size
            f.setImageDrawable(walkFrames[frameIdx])
            f.scaleX = if (dir > 0) 1f else -1f
        } else {
            f.setImageDrawable(face)
            f.scaleX = 1f
        }
        p.x = x
        wm.updateViewLayout(f, p)
        if (bubbleShown) positionBubble(false)
    }

    // ---------- speech bubble ----------

    private val hideBubble = Runnable { removeBubble() }

    private val phraseRun = object : Runnable {
        override fun run() {
            if (panel == null) {
                val list = I18n.phrases(this@OverlayService)
                say(list[rnd.nextInt(list.size)])
            }
            handler.postDelayed(this, 45000L + rnd.nextInt(60000))
        }
    }

    private fun makeBubble(): TextView {
        val tv = TextView(this)
        tv.textSize = 14f
        tv.setTextColor(Color.parseColor("#3A2A1E"))
        tv.maxWidth = dp(240)
        tv.setPadding(dp(12), dp(8), dp(12), dp(8))
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#FFF4E6"))
        bg.setStroke(dp(2), Color.parseColor("#E8742C"))
        bg.cornerRadius = dp(14).toFloat()
        tv.background = bg
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.BOTTOM or Gravity.START
        bubbleP = lp
        bubbleV = tv
        return tv
    }

    private fun say(text: String, ms: Long = 6000L) {
        val b = bubbleV ?: makeBubble()
        b.text = text
        val needAdd = !bubbleShown
        positionBubble(needAdd)
        bubbleShown = true
        handler.removeCallbacks(hideBubble)
        handler.postDelayed(hideBubble, ms)
    }

    private fun positionBubble(add: Boolean) {
        val b = bubbleV ?: return
        val p = bubbleP ?: return
        val sw = screenW()
        b.measure(
            View.MeasureSpec.makeMeasureSpec(sw, View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val bw = b.measuredWidth
        val maxBx = maxOf(dp(8), sw - bw - dp(8))
        p.x = (x + foxW() / 2 - bw / 2).coerceIn(dp(8), maxBx)
        p.y = foxBottom() + foxH() + dp(2)
        if (add) wm.addView(b, p) else wm.updateViewLayout(b, p)
    }

    private fun removeBubble() {
        handler.removeCallbacks(hideBubble)
        if (bubbleShown) {
            try {
                wm.removeView(bubbleV)
            } catch (e: Exception) {
            }
            bubbleShown = false
        }
    }

    // ---------- chat panel ----------

    private fun togglePanel() {
        if (panel != null) closePanel() else openPanel()
    }

    private fun openPanel() {
        removeBubble()
        val sw = screenW()

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), dp(12), dp(12), dp(12))
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#FFF4E6"))
        bg.setStroke(dp(2), Color.parseColor("#E8742C"))
        bg.cornerRadius = dp(16).toFloat()
        col.background = bg

        val reply = TextView(this)
        reply.textSize = 15f
        reply.setTextColor(Color.parseColor("#222222"))
        reply.text = I18n.t(this, "chat_hello")
        val scroll = ScrollView(this)
        scroll.addView(reply)
        col.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(150)))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL

        val et = EditText(this)
        et.hint = I18n.t(this, "chat_hint")
        et.setTextColor(Color.parseColor("#222222"))
        et.setHintTextColor(Color.parseColor("#888888"))
        et.maxLines = 3
        et.imeOptions = EditorInfo.IME_ACTION_SEND
        et.setHorizontallyScrolling(false)
        et.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendMessage()
                true
            } else {
                false
            }
        }
        row.addView(et, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val send = Button(this)
        send.text = "➤"
        send.setOnClickListener { sendMessage() }
        row.addView(send, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        val close = Button(this)
        close.text = "✕"
        close.setOnClickListener { closePanel() }
        row.addView(close, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        col.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        val lp = WindowManager.LayoutParams(
            sw - dp(24),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = dp(48)
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        wm.addView(col, lp)

        panel = col
        replyTv = reply
        inputEt = et
        et.requestFocus()
    }

    private fun closePanel() {
        panel?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        panel = null
        replyTv = null
        inputEt = null
    }

    private fun sendMessage() {
        val et = inputEt ?: return
        val reply = replyTv ?: return
        val q = et.text.toString().trim()
        if (q.isEmpty() || busy) return
        val key = Prefs.key(this)
        if (key.isEmpty()) {
            reply.text = I18n.t(this, "no_key")
            return
        }
        et.setText("")
        history.add(Pair("user", q))
        while (history.size > 12) history.removeAt(0)
        reply.text = I18n.t(this, "thinking")
        busy = true
        val langName = when (I18n.lang(this)) {
            "uz" -> "Uzbek"
            "ru" -> "Russian"
            else -> "English"
        }
        Gemini.ask(key, Prefs.model(this), langName, ArrayList(history)) { result, error ->
            busy = false
            if (result != null) {
                history.add(Pair("model", result))
                replyTv?.text = result
            } else {
                if (history.isNotEmpty()) history.removeAt(history.size - 1)
                replyTv?.text = I18n.t(this, "error") + ": " + (error ?: "")
            }
        }
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        removeBubble()
        closePanel()
        fox?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        fox = null
        super.onDestroy()
    }
}
